# Tasarımcı Akademisi Web Sitesi

Bu proje, Tasarımcı Akademisi web sitesinin klonudur. HTML, CSS ve JavaScript kullanılarak oluşturulmuştur.

## Özellikler

- Responsive tasarım
- Modern ve kullanıcı dostu arayüz
- Animasyonlu geçişler
- SSS bölümü
- Mobil uyumlu menü

## Kurulum

1. Repoyu klonlayın:
```bash
git clone https://github.com/kullaniciadi/tasarimci-akademisi.git
```

2. İndex.html dosyasını bir web tarayıcısında açın.

## Geliştirme

Projeyi geliştirmek için:

1. Yeni bir branch oluşturun
2. Değişikliklerinizi yapın
3. Pull request gönderin

## Lisans

Bu proje MIT lisansı altında lisanslanmıştır. 